from django.apps import AppConfig


class ImageuploadConfig(AppConfig):
    name = 'ImageUpload'
